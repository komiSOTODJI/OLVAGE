
SELECT (t.train_id || ' ' || d.city || ' - ' || a.city) AS TRAIN,(SUM(w.nb_seat)-COUNT(ti.ticket_id)) AS "PLACE LIBRE"
FROM T_TRAIN  t
INNER JOIN T_WAGON_TRAIN wt
ON t.train_id = wt.train_id
INNER JOIN T_TICKET ti
ON ti.wag_tr_id = wt.wag_tr_id
INNER JOIN T_WAGON w
ON w.wagon_id = wt.wagon_id
INNER JOIN T_STATION d
ON t.departure_station_id=d.station_id
INNER JOIN T_STATION a
ON t.arrival_station_id=a.station_id 
WHERE  t.distance > 300 AND t.departure_time LIKE ’22/10/20’
GROUP BY t.train_id,d.city,a.city
ORDER BY t.train_id;