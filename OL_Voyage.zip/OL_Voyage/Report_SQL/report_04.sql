

SELECT UPPER(CONCAT(CONCAT(c.last_name,' '),c.first_name)) CUSTOMER,
	CASE 
		WHEN c.pass_date IS NULL THEN  CONCAT(CONCAT(p.pass_name,’ ‘) ,‘Aucun’)
		WHEN c.pass_date >='14/10/2019'  THEN CONCAT(CONCAT(p.pass_name,’ ‘) ,‘Périmé’)
		ELSE p.pass_name
	END AS ABONNEMENT
FROM T_CUSTOMER c
FULL JOIN T_PASS p ON p.pass_id = c.pass_id
ORDER BY  c.last_name, c.first_name;