

SELECT UPPER(CONCAT(CONCAT(last_name,' '),first_name)) EMPLOYEE,COUNT(reservation_id) NB_RESERVATION
FROM T_RESERVATION
NATURAL JOIN T_EMPLOYEE
HAVING COUNT(reservation_id ) >= 
	ALL(SELECT COUNT(reservation_id) 
		FROM T_RESERVATION
		NATURAL JOIN T_EMPLOYEE
		GROUP BY last_name,first_name)
GROUP BY last_name,first_name
ORDER BY COUNT(reservation_id) DESC;