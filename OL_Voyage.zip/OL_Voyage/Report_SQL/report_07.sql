
SELECT (t.train_id || ' ' ||d.city || ' - ' || a.city) AS TRAIN,COUNT(ti.ticket_id) NB_TICKET
FROM T_WAGON_TRAIN tr
NATURAL JOIN T_TICKET ti
INNER JOIN T_TRAIN t
ON tr.train_id = t.train_id
INNER JOIN T_STATION d ON t.departure_station_id = d.station_id
INNER JOIN T_STATION a ON t.arrival_station_id = a.station_id 
GROUP BY t.train_id,d.city,a.city
ORDER BY NB_TICKET DESC
OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY;