
SELECT UPPER(CONCAT(CONCAT(last_name,' '),first_name)) CUSTOMER,address
FROM T_CUSTOMER 
WHERE pass_id IS NULL AND pass_date IS NULL
ORDER BY last_name,first_name;