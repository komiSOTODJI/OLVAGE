
SELECT COUNT(c.customer_id) NB_CLIENT
FROM T_CUSTOMER c
NATURAL JOIN T_PASS p
INNER JOIN T_RESERVATION res
ON res.buyer_id = c.customer_id
INNER JOIN T_TICKET ti
ON ti.customer_id = res.buyer_id
INNER JOIN T_WAGON_TRAIN wt
ON  wt.wag_tr_id = ti.wag_tr_id
INNER JOIN T_TRAIN tr
ON  tr.train_id = wt.train_id
WHERE p.pass_name = 'Senior'  AND departure_time LIKE '%%/10/20'
GROUP BY p.pass_name;
