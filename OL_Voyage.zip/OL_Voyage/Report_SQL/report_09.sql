
SELECT (train_id || ' ' || d.city || ‘ - ‘ || a.city) AS TRAIN ,CONCAT(ROUND(distance/(24*(arrival_time-departure_time)),2), ‘ Km/h’) AS VITESSE
FROM T_TRAIN 
INNER JOIN T_STATION d
ON departure_station_id=d.station_id
INNER JOIN T_STATION a
ON arrival_station_id=a.station_id ;