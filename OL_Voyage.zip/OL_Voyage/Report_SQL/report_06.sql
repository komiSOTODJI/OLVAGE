
SELECT EMPLOYEE.e,ROUND((nbr_abonne.nbr_ab/CUSTOMER.c)*100) pourcentage,CUSTOMER.c,NB_TRAIN.tr,STATION.s,NB_RES.res,TICKET.tickets
FROM	(SELECT COUNT(employee_id) e FROM T_EMPLOYEE) EMPLOYEE,
		(SELECT COUNT(customer_id) c FROM T_CUSTOMER) CUSTOMER,
		(SELECT COUNT(train_id) tr FROM T_TRAIN) NB_TRAIN,
		(SELECT COUNT(station_id) s FROM T_STATION) STATION,
		(SELECT COUNT(reservation_id) res FROM T_RESERVATION) NB_RES,
		(SELECT COUNT(ticket_id) tickets FROM T_TICKET) TICKET,
		(SELECT COUNT((t.cus)) nbr_ab
		FROM (SELECT COUNT(cl.customer_id) cus
				FROM T_CUSTOMER cl LEFT OUTER JOIN T_PASS p ON cl.pass_id = p.pass_id
				WHERE p.pass_id IS NOT NULL AND (SYSDATE - cl.pass_date)/365 <1
				GROUP BY cl.customer_id) t) nbr_abonne;
