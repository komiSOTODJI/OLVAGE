
SELECT (train_id || ' ' || d.city || ' - ' || a.city) AS TRAIN ,pass_name,t.price-t.price * (discount_pct/100) AS  WEEK,t.price-t.price * (discount_we_pct/100) AS WEEK_END
FROM T_TRAIN t
CROSS JOIN T_PASS
INNER JOIN T_STATION d
ON departure_station_id=d.station_id
INNER JOIN T_STATION a
ON arrival_station_id=a.station_id 
WHERE d.city='Paris'
ORDER BY train_id; 