
SELECT train_id, d.city || '  '|| TO_CHAR(departure_time,'(DD/MM/YY HH24:MI)') || ' - ' || a.city || '  ' || TO_CHAR(arrival_time,'(DD/MM/YY HH24:MI)') TRAJET
FROM T_TRAIN
INNER JOIN T_STATION d
ON departure_station_id=d.station_id
INNER JOIN T_STATION a
ON arrival_station_id=a.station_id ; 