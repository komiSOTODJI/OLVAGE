
SELECT ti.ticket_id,CONCAT(CONCAT(c.last_name,' '),c.first_name) NAME,d.city || '  '|| TO_CHAR(departure_time,'(DD/MM/YY HH24:MI)') || ' - ' || a.city || '  ' || TO_CHAR(arrival_time,'(DD/MM/YY HH24:MI)') TRAJET
FROM t_customer c 
INNER JOIN t_reservation r  on c.customer_id = r.buyer_id
INNER JOIN t_ticket ti on r.reservation_id = ti.reservation_id
INNER JOIN t_wagon_train wt on ti.wag_tr_id = wt.wag_tr_id
INNER JOIN t_wagon w on wt.wagon_id = w.wagon_id
INNER JOIN t_train tr on wt.train_id = tr.train_id
INNER JOIN t_station d on tr.departure_station_id = d.station_id
INNER JOIN t_station a on tr.arrival_station_id = a.station_id
WHERE w.class_type = 1 AND (r.creation_date - c.birth_date)/365 < 25
AND (tr.departure_time - r.creation_date) > 20
AND tr.departure_time BETWEEN  '20/10/2020' AND '26/10/2020'
ORDER BY tr.departure_time;