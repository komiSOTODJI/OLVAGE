
SELECT reservation_id,creation_date,UPPER(e.last_name || ' '|| e.first_name) EMPLOYEE,UPPER(c.last_name || ' ' || c.first_name) CUSTOMER
FROM T_RESERVATION r
INNER JOIN T_EMPLOYEE e
ON e.employee_id=r.employee_id
INNER JOIN T_CUSTOMER c
ON customer_id = buyer_id
WHERE creation_date = 
						(SELECT  MIN(creation_date)
						FROM T_RESERVATION );
